/**
 * Created by Alec on 14.03.2016 г..
 */
public class AssignVariables {
    public static void main(String args[]){
        boolean a = false;
        String b = "Palo Alto, CA";
        short c = 32767;
        int d = 2000000000;
        double e = 0.1234567891011;
        float f = 0.5f;
        long g = 919827112351L;
        byte h = 127;
        char i = 'c';

        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);
        System.out.println(e);
        System.out.println(f);
        System.out.println(g);
        System.out.println(h);
        System.out.println(i);
    }
}
