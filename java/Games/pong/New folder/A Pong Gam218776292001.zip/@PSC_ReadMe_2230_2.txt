Title: A Pong Game
Description: I once checked on this site for a pong game,surprisingly I did not find any,so I tried to make it myself. And here you have it.I have updated my old version. Please vote for me,this version is a whole lot better. It's got random bricks that make things interesting. When the skill level changes,the background changes.You can make the applet any size, just remember to make the size of the backgrounds the same size as the applet. The game has more than one ball. To change the amount of balls change the size of the array (ball). To increase the amount of bricks change the brick array. This version also has sounds. A two player game has been added too. Check out the screenshot if you're not convinced. Enjoy!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=2230&lngWId=2

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
