package game;

public class Launcher {
    public static void main(String[] args) {
        Game game = new Game("Title game!", 400, 400);
        game.start();
    }
}
