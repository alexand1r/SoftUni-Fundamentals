package states;

import java.awt.*;

public class MenuState extends State{

    public MenuState() {

    }

    @Override
    public void tick() {

    }

    @Override
    public void render(Graphics g) {

    }
}
