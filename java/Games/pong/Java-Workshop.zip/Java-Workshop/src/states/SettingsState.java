package states;

import java.awt.*;

public class SettingsState extends State {

    public SettingsState() {

    }

    @Override
    public void tick() {

    }

    @Override
    public void render(Graphics g) {

    }
}
