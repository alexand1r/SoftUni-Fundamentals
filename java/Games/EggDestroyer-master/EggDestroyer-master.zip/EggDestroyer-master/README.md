EggDestroyer
============

Let's break some eggs!!!

GOAL:
Destroy all the dino eggs and get the highest possible high score!

Tip: Press SPACE while you are in "FANGBANG" mode.

gl hf!
